/*
** test2.c for  in /home/charra_s/Downloads
** 
** Made by Sofiane Charrad
** Login   <charra_s@epitech.net>
** 
** Started on  Tue Jun 23 13:23:21 2015 Sofiane Charrad
** Last update Tue Jun 23 13:24:06 2015 Sofiane Charrad
*/

#include <stdio.h>

void	main()
{
  printf("Salut\n");
}
